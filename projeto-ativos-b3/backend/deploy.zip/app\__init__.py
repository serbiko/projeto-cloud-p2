"""
API de Ativos B3 - Backend FastAPI
"""
__version__ = "1.0.0"